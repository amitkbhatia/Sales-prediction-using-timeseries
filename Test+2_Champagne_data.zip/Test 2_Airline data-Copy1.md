
###### Objective- The objective of this analysis is to predict the number of monthly sales of champagne for the Perrin Freres labe
I have used Python programming (Jupyter notebook). Data source and python code is provided within this document to ensure fully reproducible research.

Data link- https://datamarket.com/data/set/22r5/perrin-freres-monthly-champagne-sales-millions-64-72#!ds=22r5&display=line

Data Description-The dataset provides the number of monthly sales of champagne from January 1964 to September 1972.The values are a count of millions of sales and there are 105 observations.

###### 2.	Plot out your time series variable(s) separately.  Tell me using your Mark I eyeball whether or not you think the time series data set is stationary in terms of constant mean and also constant variance.


```python
# load dataset using read_csv()
from pandas import read_csv
series = read_csv('champagne.csv', header=0, parse_dates=[0], index_col=0, squeeze=True)
print(type(series))
print(series.head())
```

    <class 'pandas.core.series.Series'>
    Month
    1964-01-01    2815
    1964-02-01    2672
    1964-03-01    2755
    1964-04-01    2721
    1964-05-01    2946
    Name: Sales, dtype: int64
    


```python
# calculate descriptive statistics
from pandas import Series
series = Series.from_csv('champagne.csv', header=0)
print(series.describe())
```

    count      105.000000
    mean      4761.152381
    std       2553.502601
    min       1413.000000
    25%       3113.000000
    50%       4217.000000
    75%       5221.000000
    max      13916.000000
    Name: Sales, dtype: float64
    

I noted the following key observations
The mean is about 4,641, which we might consider our level in this series.
The standard deviation (average spread from the mean) is relatively large at 2,486 sales.
The percentiles along with the standard deviation do suggest a large spread to the data.


```python
from matplotlib import pyplot
series.plot()
pyplot.figure(1)

# line plot
pyplot.subplot(211)
pyplot.plot(series)

# histogram

pyplot.subplot(212)
pyplot.hist(series)
pyplot.show()
```


![png](output_6_0.png)


The first showing the time series as a line plot and the second showing the observations as a histogram.

Key observations
There may be an increasing trend of sales over time.
There appears to be systematic seasonality to the sales for each year.
The seasonal signal appears to be growing over time, suggesting a multiplicative relationship (increasing change).


```python
# separate out a validation dataset
from pandas import Series
series = Series.from_csv('champagne.csv', header=0)
split_point = len(series) - 12
dataset, validation = series[0:split_point], series[split_point:]
print('Dataset %d, Validation %d' % (len(dataset), len(validation)))
dataset.to_csv('dataset.csv')
validation.to_csv('validation.csv')
```

    Dataset 93, Validation 12
    

Dataset.csv: Observations from January 1964 to September 1971 (93 observations).
Validation.csv: Observations from October 1971 to September 1972 (12 observations).


```python
# multiple line plots of time series
# multiple line plots of time series
from pandas import Series
from pandas import DataFrame
from pandas import TimeGrouper
from matplotlib import pyplot
series = Series.from_csv('dataset.csv')
groups = series['1964':'1970'].groupby(TimeGrouper('A'))
years = DataFrame()
pyplot.figure()
i = 1
n_groups = len(groups)
for name, group in groups:
	pyplot.subplot((n_groups*100) + 10 + i)
	i += 1
	pyplot.plot(group)
pyplot.show()
```


![png](output_11_0.png)



```python
# boxplots of time series
from pandas import Series
from pandas import DataFrame
from pandas import TimeGrouper
from matplotlib import pyplot
series = Series.from_csv('dataset.csv')
groups = series['1964':'1970'].groupby(TimeGrouper('A'))
years = DataFrame()
for name, group in groups:
    years[name.year] = group.values
years.boxplot()
pyplot.show()
```


![png](output_12_0.png)


Key observations
Median value is increasing
There are outliers each year (black crosses); these may be the tops or bottoms of the seasonal cycle.
The last year, 1970, does look different from the trend in prior years

Based on the above graphs, the time series is almost certainly non-stationary. We can make it stationary this by first
differencing the series and using a statistical test to confirm that the result is stationary.


```python
# calculation of statistics of partitioned time series data
```

###### 3.	Plot the ACF for each time series data set. Looking at ACF, does it look like there may be a trend or non-constant mean for each time series?


```python
X = series.values
train_size = int(len(X) * 0.50)
train, test = X[0:train_size], X[train_size:len(X)]
print('Observations: %d' % (len(X)))
print('Training Observations: %d' % (len(train)))
print('Testing Observations: %d' % (len(test)))
pyplot.plot(train)
pyplot.plot([None for i in train] + [x for x in test])
pyplot.show()
```

    Observations: 93
    Training Observations: 46
    Testing Observations: 47
    


![png](output_17_1.png)



```python
# calculate and plot monthly average
from pandas import Series
from matplotlib import pyplot
# create a boxplot of monthly data
from pandas import Series
from pandas import DataFrame
from pandas import TimeGrouper
from matplotlib import pyplot
from pandas import concat
resample = series.resample('M')
monthly_mean = resample.mean()
print(monthly_mean.head())
monthly_mean.plot()
pyplot.show()
```

    1964-01-31    2815
    1964-02-29    2672
    1964-03-31    2755
    1964-04-30    2721
    1964-05-31    2946
    Freq: M, dtype: int64
    


![png](output_18_1.png)


Both Box plot and head map indicates that number of paasengers are high in sixth and seventh month


```python
### ACF plot for each time series data set. 
```

We would expect the ACF for the AR(k) time series to be strong to a lag of k and the inertia of that relationship would carry on to subsequent lag values, trailing off at some point as the effect was weakened


```python
from pandas.tools.plotting import autocorrelation_plot
autocorrelation_plot(series)
pyplot.show()
```


![png](output_22_0.png)


ACF captures the relationship of an observation with past observations in the same and opposite seasons or times of year.


```python
# autocorrelation plot of time series 
from pandas import Series
from matplotlib import pyplot
from statsmodels.graphics.tsaplots import plot_acf
plot_acf(series, lags=60)
pyplot.show()
```


![png](output_24_0.png)


We observe that auto correlation is low and decreasing with lag.The seasonality in the series is seemingly year-to-year. Seasonal data can be differenced by subtracting the observation from the same time in the previous cycle, in this case the same month in the previous year.

###### 4.	Now let’s examine each time series data set using unit root tests.   First use the KPSS test for each time series data set and tell me if the test suggests if there is a constant mean or not.  Then see if you can confirm your KPSS evaluation using the Augmented Dickey Fuller test for each time series.  Tell me what you find for each data set.

Kwiatkowski-Philips-Schmidt-Shin (KPSS) test Here accepting null hypothesis means that the series is stationary, and small p-value suggest that the series is NOT stationary and a differencing may be required
###### KPSS output using R

I have used R for KPSS test as it is not available in Python

Code and output for kpss test

kpss_test1 <- kpss.test(df[ ,2], null="Level")
kpss_test1

KPSS Test for Level Stationarity

data:  df[, 2]
KPSS Level = 1.9367, Truncation lag parameter = 13, p-value = 0.01

> kpss_test2 <- kpss.test(df[ ,2], null="Trend")

Warning message:
In kpss.test(df[, 2], null = "Trend") :
  p-value smaller than printed p-value
> kpss_test2

	KPSS Test for Trend Stationarity

data:  df[, 2]
KPSS Trend = 0.80825, Truncation lag parameter = 13, p-value = 0.01

### Augemented Dickey Fuller Test

The Augmented Dickey-Fuller test is the most common unit root test used. It is a regression of the first difference of the variable on its lagged level as well as additional lags of the first difference. The null is that the series contains a unit root, and the alternative is that the series is stationary.

By default, the number of lags is selected by minimizing the AIC across a range of lag lengths (which can be set using max_lag when initializing the model). Additionally, the basic test includes a constant in the ADF regression.

Null Hypothesis (H0): If accepted, it suggests the time series has a unit root, meaning it is non-stationary. It has some time dependent structure.

Alternate Hypothesis (H1): The null hypothesis is rejected; it suggests the time series does not have a unit root, meaning it is stationary. It does not have time-dependent structure.


```python
from statsmodels.tsa.stattools import adfuller
X = series.values
result = adfuller(X)
print('Results of Dickey-Fuller Test:')
print('ADF Statistic: %f' % result[0])
print('p-value: %f' % result[1])
print('Critical Values:')
for key, value in result[4].items():
    print('\t%s: %.3f' % (key, value))
```

    Results of Dickey-Fuller Test:
    ADF Statistic: -1.445970
    p-value: 0.560050
    Critical Values:
    	1%: -3.514
    	5%: -2.898
    	10%: -2.586
    

Running the Dickey- fuller test gives the test statistic value of -1.445. The more negative this statistic, the more likely we are to reject the null hypothesis (we have a stationary dataset). As part of the output, I get a look-up table to help determine the ADF statistic ( statistic value of -1.445 is more than the value of -3.5 at 1%. This suggests that we can not reject the null hypothesis with even a signifcance level of less than 5%. This means that the process has no unit root, and in turn that the time series is non-stationary or have time-dependent structure.

#### PACF


```python
from statsmodels.graphics.tsaplots import plot_pacf
plot_pacf(series, lags=500)
pyplot.show()
```


![png](output_33_0.png)


PACF only describes the direct relationship between an observation and its lag. This would suggest that there would be no correlation for lag values beyond k.


```python
from statsmodels.graphics.tsaplots import plot_pacf
plot_pacf(series, lags=50)
pyplot.show()
```


![png](output_35_0.png)


PCAF graphs also indicates seasonality.The PACF is better for AR models, and also shows the weekly and yearly seasons, although the correlation is lost faster with the lag.

###### 5.	Review the decisions in step # 4.  If the test suggests that there is a non-constant mean then use differencing to create a new differenced variable for that time series data set.  

a.	Plot out the data for the new differenced data set(s).  Tell me if it looks like the differencing got rid of the trend or non-constant mean.
b.	Plot the ACF for the differenced time serie(s). Tell me if this new ACF plot looks like there now is no trend.


```python
# create and summarize stationary version of time series
from pandas import Series
from statsmodels.tsa.stattools import adfuller
from matplotlib import pyplot

# create a differenced series
def difference(dataset, interval=1):
	diff = list()
	for i in range(interval, len(dataset)):
		value = dataset[i] - dataset[i - interval]
		diff.append(value)
	return Series(diff)

series = Series.from_csv('dataset.csv')
X = series.values
X = X.astype('float32')
# difference data
months_in_year = 12
stationary = difference(X, months_in_year)
stationary.index = series.index[months_in_year:]
# check if stationary
result = adfuller(stationary)
print('ADF Statistic: %f' % result[0])
print('p-value: %f' % result[1])
print('Critical Values:')
for key, value in result[4].items():
	print('\t%s: %.3f' % (key, value))
# save
stationary.to_csv('stationary.csv')
# plot
stationary.plot()
pyplot.show()
```

    ADF Statistic: -7.134898
    p-value: 0.000000
    Critical Values:
    	1%: -3.515
    	5%: -2.898
    	10%: -2.586
    


![png](output_38_1.png)


Yes, based on differencing plot we observe that series has constant mean and variance as compared to without differencing

The results show that the test statistic value -7.134898 is smaller than the critical value at 1% of -3.515. This
suggests that we can reject the null hypothesis with a signicance level of less than 1% . Rejecting the null hypothesis means that the process has no unit root, and in turn that the time series is stationary or does not have
time-dependent structure.


```python
# invert differenced value
def inverse_difference(history, yhat, interval=1):
    return yhat + history[-interval]
```

##### Plots for insights into how to set the p and q variables for the ARIMA model.


```python
# ACF and PACF plots of time series
from pandas import Series
from statsmodels.graphics.tsaplots import plot_acf
from statsmodels.graphics.tsaplots import plot_pacf
from matplotlib import pyplot
series = Series.from_csv('stationary.csv')
pyplot.figure()
pyplot.subplot(211)
plot_acf(series, ax=pyplot.gca())
pyplot.subplot(212)
plot_pacf(series, ax=pyplot.gca())
pyplot.show()
```


![png](output_43_0.png)


The ACF shows a significant lag for 1 month.
The PACF shows a signifcant lag for 1 month, with perhaps some significant lag at 12 and 13 months.
Both the ACF and PACF show a drop-off at the same point, perhaps suggesting a mix of AR and MA.


```python
# evaluate manually configured ARIMA model
from pandas import Series
from sklearn.metrics import mean_squared_error
from statsmodels.tsa.arima_model import ARIMA
from math import sqrt

# create a differenced series
def difference(dataset, interval=1):
	diff = list()
	for i in range(interval, len(dataset)):
		value = dataset[i] - dataset[i - interval]
		diff.append(value)
	return diff

# invert differenced value
def inverse_difference(history, yhat, interval=1):
	return yhat + history[-interval]

# load data
series = Series.from_csv('dataset.csv')
# prepare data
X = series.values
X = X.astype('float32')
train_size = int(len(X) * 0.50)
train, test = X[0:train_size], X[train_size:]
# walk-forward validation
history = [x for x in train]
predictions = list()
for i in range(len(test)):
	# difference data
	months_in_year = 12
	diff = difference(history, months_in_year)
	# predict
	model = ARIMA(diff, order=(0,0,1))
	model_fit = model.fit(trend='nc', disp=0)
	yhat = model_fit.forecast()[0]
	yhat = inverse_difference(history, yhat, months_in_year)
	predictions.append(yhat)
	# observation
	obs = test[i]
	history.append(obs)
	print('>Predicted=%.3f, Expected=%3.f' % (yhat, obs))
# report performance
rmse = sqrt(mean_squared_error(test, predictions))
print('RMSE: %.3f' % rmse)
print(model_fit.summary())
```

    >Predicted=7533.503, Expected=8314
    >Predicted=9513.501, Expected=10651
    >Predicted=5797.247, Expected=3633
    >Predicted=2462.540, Expected=4292
    >Predicted=3922.862, Expected=4154
    >Predicted=4545.659, Expected=4121
    >Predicted=4455.107, Expected=4647
    >Predicted=4567.683, Expected=4753
    >Predicted=3691.090, Expected=3965
    >Predicted=1684.956, Expected=1723
    >Predicted=4744.831, Expected=5048
    >Predicted=5474.600, Expected=6922
    >Predicted=8556.384, Expected=9858
    >Predicted=10925.314, Expected=11331
    >Predicted=3726.032, Expected=4016
    >Predicted=4360.617, Expected=3957
    >Predicted=4059.717, Expected=4510
    >Predicted=4223.040, Expected=4276
    >Predicted=4659.008, Expected=4968
    >Predicted=4823.543, Expected=4677
    >Predicted=3931.824, Expected=3523
    >Predicted=1629.240, Expected=1821
    >Predicted=5091.520, Expected=5222
    >Predicted=6951.792, Expected=6872
    >Predicted=9839.749, Expected=10803
    >Predicted=11548.695, Expected=13916
    >Predicted=4687.849, Expected=2639
    >Predicted=3636.164, Expected=2899
    >Predicted=4369.347, Expected=3370
    >Predicted=4055.001, Expected=3740
    >Predicted=4897.697, Expected=2927
    >Predicted=4221.787, Expected=3986
    >Predicted=3470.510, Expected=4217
    >Predicted=2002.302, Expected=1738
    >Predicted=5159.205, Expected=5221
    >Predicted=6886.738, Expected=6424
    >Predicted=10692.994, Expected=9842
    >Predicted=13707.644, Expected=13076
    >Predicted=2479.764, Expected=3934
    >Predicted=3249.638, Expected=3162
    >Predicted=3349.928, Expected=4286
    >Predicted=3956.505, Expected=4676
    >Predicted=3100.015, Expected=5010
    >Predicted=4478.173, Expected=4874
    >Predicted=4318.374, Expected=4633
    >Predicted=1822.509, Expected=1659
    >Predicted=5177.274, Expected=5951
    RMSE: 939.464
                                  ARMA Model Results                              
    ==============================================================================
    Dep. Variable:                      y   No. Observations:                   80
    Model:                     ARMA(0, 1)   Log Likelihood                -650.379
    Method:                       css-mle   S.D. of innovations            820.844
    Date:                Thu, 04 May 2017   AIC                           1304.758
    Time:                        23:13:58   BIC                           1309.522
    Sample:                             0   HQIC                          1306.668
                                                                                  
    ==============================================================================
                     coef    std err          z      P>|z|      [95.0% Conf. Int.]
    ------------------------------------------------------------------------------
    ma.L1.y        0.2679      0.099      2.706      0.008         0.074     0.462
                                        Roots                                    
    =============================================================================
                     Real           Imaginary           Modulus         Frequency
    -----------------------------------------------------------------------------
    MA.1           -3.7333           +0.0000j            3.7333            0.5000
    -----------------------------------------------------------------------------
    


```python
ARIMA(1,1,1)
AIC     1287.108
BIC     1294.217
HQIC    1289.956

ARIMA(0,0,1)

AIC 1304.758
BIC 1309.522
HQIC 1306.668
```


```python
# grid search ARIMA parameters for time series
import warnings
from pandas import Series
from statsmodels.tsa.arima_model import ARIMA
from sklearn.metrics import mean_squared_error
from math import sqrt
import numpy

# create a differenced series
def difference(dataset, interval=1):
	diff = list()
	for i in range(interval, len(dataset)):
		value = dataset[i] - dataset[i - interval]
		diff.append(value)
	return numpy.array(diff)

# invert differenced value
def inverse_difference(history, yhat, interval=1):
	return yhat + history[-interval]

# evaluate an ARIMA model for a given order (p,d,q) and return RMSE
def evaluate_arima_model(X, arima_order):
	# prepare training dataset
	X = X.astype('float32')
	train_size = int(len(X) * 0.50)
	train, test = X[0:train_size], X[train_size:]
	history = [x for x in train]
	# make predictions
	predictions = list()
	for t in range(len(test)):
		# difference data
		months_in_year = 12
		diff = difference(history, months_in_year)
		model = ARIMA(diff, order=arima_order)
		model_fit = model.fit(trend='nc', disp=0)
		yhat = model_fit.forecast()[0]
		yhat = inverse_difference(history, yhat, months_in_year)
		predictions.append(yhat)
		history.append(test[t])
	# calculate out of sample error
	rmse = sqrt(mean_squared_error(test, predictions))
	return rmse

# evaluate combinations of p, d and q values for an ARIMA model
def evaluate_models(dataset, p_values, d_values, q_values):
	dataset = dataset.astype('float32')
	best_score, best_cfg = float("inf"), None
	for p in p_values:
		for d in d_values:
			for q in q_values:
				order = (p,d,q)
				try:
					rmse = evaluate_arima_model(dataset, order)
					if rmse < best_score:
						best_score, best_cfg = rmse, order
					print('ARIMA%s RMSE=%.3f' % (order,rmse))
				except:
					continue
	print('Best ARIMA%s RMSE=%.3f' % (best_cfg, best_score))

# load dataset
series = Series.from_csv('dataset.csv')
# evaluate parameters
p_values = range(0, 7)
d_values = range(0, 3)
q_values = range(0, 7)
warnings.filterwarnings("ignore")
evaluate_models(series.values, p_values, d_values, q_values)
```

    ARIMA(0, 0, 1) RMSE=939.464
    ARIMA(0, 0, 2) RMSE=962.289
    ARIMA(0, 0, 3) RMSE=944.237
    ARIMA(0, 0, 4) RMSE=958.779
    ARIMA(0, 0, 5) RMSE=986.835
    ARIMA(0, 0, 6) RMSE=1087.034
    ARIMA(0, 1, 1) RMSE=958.296
    ARIMA(0, 2, 1) RMSE=1146.987
    ARIMA(1, 0, 0) RMSE=944.449
    ARIMA(1, 1, 0) RMSE=1070.204
    ARIMA(1, 1, 1) RMSE=956.953
    ARIMA(1, 2, 0) RMSE=1555.858
    ARIMA(2, 0, 0) RMSE=955.134
    ARIMA(2, 1, 0) RMSE=1030.467
    ARIMA(2, 1, 1) RMSE=980.950
    ARIMA(2, 2, 0) RMSE=1346.598
    ARIMA(2, 2, 1) RMSE=1039.643
    ARIMA(3, 0, 0) RMSE=959.165
    ARIMA(3, 1, 0) RMSE=1028.226
    ARIMA(3, 1, 1) RMSE=979.939
    ARIMA(3, 2, 0) RMSE=1244.847
    ARIMA(4, 0, 0) RMSE=968.411
    ARIMA(4, 1, 0) RMSE=1046.524
    ARIMA(4, 1, 1) RMSE=1006.249
    ARIMA(4, 2, 0) RMSE=1227.556
    ARIMA(4, 2, 1) RMSE=1055.484
    ARIMA(5, 0, 0) RMSE=987.690
    ARIMA(5, 1, 0) RMSE=1042.642
    ARIMA(5, 1, 1) RMSE=1023.404
    ARIMA(5, 1, 2) RMSE=1003.114
    ARIMA(5, 2, 1) RMSE=1053.709
    ARIMA(6, 0, 0) RMSE=996.466
    ARIMA(6, 1, 0) RMSE=1018.211
    ARIMA(6, 1, 1) RMSE=1023.761
    ARIMA(6, 1, 2) RMSE=1033.430
    Best ARIMA(0, 0, 1) RMSE=939.464
    

The results show that the best configuration discovered was ARIMA(0,0,1) with an RMSE of 939.464 and we will select this model

An econometric term used for observed time series. ARCH models are used to model financial time series with time varying volatility, such as stock price

--- FINAL VALUES: 
loglikelihood = -4441.63088090 (steplength = 6.4e-005)
Parameters:       8.6186     0.46756     0.58997
Gradients:  -9.9170e-008-8.4956e-007-5.6512e-007 (norm 7.27e-004)

theta[0]:        694.087 (1.61111)
theta[1]:        3032.46 (136.765)
theta[2]:       0.589967 (0.0392431)


Function evaluations: 50
Evaluations of gradient: 13

Model 1: GARCH, using observations 2004-01-03:2013-01-02 (T = 3288)
Dependent variable: demand
Standard errors based on Hessian

             coefficient   std. error      z       p-value 
  ---------------------------------------------------------
  const       694.087        1.61111     430.8    0.0000    ***

  alpha(0)   3032.46       136.765        22.17   6.28e-109 ***
  alpha(1)      0.589967     0.0392431    15.03   4.42e-051 ***

Mean dependent var   692.7389   S.D. dependent var   80.53406
Log-likelihood      −18871.61   Akaike criterion     37751.22
Schwarz criterion    37775.61   Hannan-Quinn         37759.96

Unconditional error variance = 7395.65
Likelihood ratio test for (G)ARCH terms:
  Chi-square(1) = 446.678 [3.81159e-099]


from arch import arch_model
am = arch_model(diff)
res = am.fit()

An econometric term used for observed time series. ARCH models are used to model financial time series with time-varying volatility, such as stock prices. 

###### PACF Plot the PACF for each of the time series data sets.  Using the combined information from the ACFs you plotted earlier along with the information in the PACFs, tell me for each of the time series data sets if you see autoregressive and/or moving average processes in them.  


```python
# summarize ARIMA forecast residuals
from pandas import Series
from pandas import DataFrame
from statsmodels.tsa.arima_model import ARIMA
from matplotlib import pyplot

# create a differenced series
def difference(dataset, interval=1):
	diff = list()
	for i in range(interval, len(dataset)):
		value = dataset[i] - dataset[i - interval]
		diff.append(value)
	return diff

# invert differenced value
def inverse_difference(history, yhat, interval=1):
	return yhat + history[-interval]

# load data
series = Series.from_csv('dataset.csv')
# prepare data
X = series.values
X = X.astype('float32')
train_size = int(len(X) * 0.50)
train, test = X[0:train_size], X[train_size:]
# walk-forward validation
history = [x for x in train]
predictions = list()
for i in range(len(test)):
	# difference data
	months_in_year = 12
	diff = difference(history, months_in_year)
	# predict
	model = ARIMA(diff, order=(0,0,1))
	model_fit = model.fit(trend='nc', disp=0)
	yhat = model_fit.forecast()[0]
	yhat = inverse_difference(history, yhat, months_in_year)
	predictions.append(yhat)
	# observation
	obs = test[i]
	history.append(obs)
# errors
residuals = [test[i]-predictions[i] for i in range(len(test))]
residuals = DataFrame(residuals)
print(residuals.describe())
# plot
pyplot.figure()
pyplot.subplot(211)
residuals.hist(ax=pyplot.gca())
pyplot.subplot(212)
residuals.plot(kind='kde', ax=pyplot.gca())
pyplot.show()
```

                     0
    count    47.000000
    mean    165.904738
    std     934.696197
    min   -2164.247449
    25%    -289.651758
    50%     191.759548
    75%     732.992187
    max    2367.304748
    


![png](output_54_1.png)


Distribution has a right shift and that the mean is non-zero at 165.904. The distribution of residual errors suggest a Gaussian-like distribution with a bumpy left tail, providing further evidence that perhaps a power transform
might be worth exploring.


```python
# ACF and PACF plots of residual errors of bias corrected forecasts
from pandas import Series
from pandas import DataFrame
from statsmodels.tsa.arima_model import ARIMA
from matplotlib import pyplot
from statsmodels.graphics.tsaplots import plot_acf
from statsmodels.graphics.tsaplots import plot_pacf

# create a differenced series
def difference(dataset, interval=1):
	diff = list()
	for i in range(interval, len(dataset)):
		value = dataset[i] - dataset[i - interval]
		diff.append(value)
	return diff

# invert differenced value
def inverse_difference(history, yhat, interval=1):
	return yhat + history[-interval]

# load data
series = Series.from_csv('dataset.csv')
# prepare data
X = series.values
X = X.astype('float32')
train_size = int(len(X) * 0.50)
train, test = X[0:train_size], X[train_size:]
# walk-forward validation
history = [x for x in train]
predictions = list()
for i in range(len(test)):
	# difference data
	months_in_year = 12
	diff = difference(history, months_in_year)
	# predict
	model = ARIMA(diff, order=(0,0,1))
	model_fit = model.fit(trend='nc', disp=0)
	yhat = model_fit.forecast()[0]
	yhat = inverse_difference(history, yhat, months_in_year)
	predictions.append(yhat)
	# observation
	obs = test[i]
	history.append(obs)
# errors
residuals = [test[i]-predictions[i] for i in range(len(test))]
residuals = DataFrame(residuals)
print(residuals.describe())
# plot
pyplot.figure()
pyplot.subplot(211)
plot_acf(residuals, ax=pyplot.gca())
pyplot.subplot(212)
plot_pacf(residuals, ax=pyplot.gca())
pyplot.show()
```

                     0
    count    47.000000
    mean    165.904738
    std     934.696197
    min   -2164.247449
    25%    -289.651758
    50%     191.759548
    75%     732.992187
    max    2367.304748
    


![png](output_56_1.png)


The results suggest that what little autocorrelation is present in the time series has been
captured by the model.
